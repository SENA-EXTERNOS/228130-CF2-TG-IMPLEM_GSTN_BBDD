function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5nWvcjn11dW":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

